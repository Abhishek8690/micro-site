 // for menu 
 var hamburger = document.getElementById("hamburger_id");
 var menu = document.getElementById("menu-id");
 hamburger.addEventListener("click",HandleMenu);
 function HandleMenu() {
    menu.classList.remove("d-none")
   }

  