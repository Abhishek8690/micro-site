//fetch code for products 
let product_container = document.getElementById('product-slideshow-container');
let url = 'https://dummyjson.com/products';
fetch(url)
  .then(response => response.json())
  .then((data) => {
    let authors = data.products;
    let link = window.location.href;
    link = link.replace("index.html","templates/pdp.html")
    authors.map(function(author) {
      let img = document.createElement('img');
      let anchor = document.createElement('a');
      let slides = document.createElement('div');
      img.setAttribute("src",author.images[0])
      img.setAttribute("alt","cannot find image")
      img.setAttribute("class","product-image")
      anchor.setAttribute("href",link)
      slides.setAttribute("class","Product-slides fades");
      anchor.setAttribute("id",author.id);
      anchor.setAttribute("class","product-anchor")
      anchor.appendChild(img);
      slides.appendChild(anchor);
      product_container.appendChild(slides);
    });
  }).then(() =>{
    // //product slide code
    let prev = document.getElementById("prev-id");
    let next = document.getElementById("next-id");
    let Product_slides = document.getElementsByClassName("Product-slides");
    let Product_slideIndex = 1;
    prev.addEventListener("click",(e)=>{plusProductSlides(e,-1)});
    next.addEventListener("click",(e)=>{plusProductSlides(e,1)});
    showProductSlides(Product_slideIndex);
    function plusProductSlides(e,num) {
      e.preventDefault();
      showProductSlides(Product_slideIndex += num);
    }
    function showProductSlides(num) {
      let j;
      if (num > Product_slides.length) {Product_slideIndex = 1}    
      if (num < 1) {Product_slideIndex = Product_slides.length}
      for (j = 0; j < Product_slides.length; j++) {
        Product_slides[j].style.display = "none";  
      }
      Product_slides[Product_slideIndex-1].style.display = "block"; 
    }
    // display pdp according to clicked image
    let product_anchor = document.getElementsByClassName("product-anchor");
    let i;
    for( i=0; i<product_anchor.length; i++) {
      let element =  product_anchor[i];
      element.addEventListener("click",()=>{clickedproduct(element)})
    }
    function clickedproduct(anchor_product) {
      let clicked_product_id = anchor_product.getAttribute("id");
      //sending the id of the product to server.js
      let xhttp = new XMLHttpRequest();
      xhttp.open("POST","http://localhost:3000/posting")
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.send(JSON.stringify({"pid": clicked_product_id}));
    }
  }).catch(function(error) {
    console.log(error);
  });
