const express = require("express");
const app = express();
const bodyParser = require("body-parser");
var catchdata;
const port = 3000;
//to avoid xmlhttprequest at blocked by cors
const cors = require("cors");
app.use(cors());
app.use(bodyParser.json())

app.post("/posting", (req, res) => {
  let data = JSON.stringify(req.body);
  catchdata = data;
  return res.status(204);
});

// send data to pdp.html
app.get("/pdp", (request, response) => {
  let recieveddata = JSON.parse(catchdata);
  response.send(recieveddata.pid);
  return request;
});

//Listen On Server
app.listen(port, function (err) {
  console.log(`Server Started At Port ${port}`);
});
